﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Экзамен
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public int cout = 3; // Переменная для подсчета попыток входа

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new МEntities()) // Используем using для корректного закрытия соединения с БД
                {
                    // Ищем пользователя в БД по логину и паролю
                    var user = db.Пользователи.FirstOrDefault(s => s.Логин == log.Text && s.Пароль == pas.Text);

                    if (user != null)
                    {
                        // Получаем информацию о роли пользователя из БД
                        var role = db.Роль.FirstOrDefault(r => r.id_Роли == user.id_Роли);

                        // Переход на соответствующую форму в зависимости от роли
                        switch (role.id_Роли)
                        {
                            case 1: // Администратор
                                Admin ad = new Admin();
                                ad.Show();
                                ad.NameUser.Content = user.Имя;
                                ad.SurUser.Content = user.Фамилия;
                                ad.RoleUser.Content = user.Отчетсво;
                                this.Close();
                                break;
                            case 2: // Менеджер
                                Manager l2 = new Manager();
                                l2.Show();
                                l2.NameUser.Content = user.Имя;
                                l2.SurUser.Content = user.Фамилия;
                                l2.RoleUser.Content = user.Отчетсво;
                                this.Close();
                                break;
                            case 3: // Пользователь
                                UserSis Ac = new UserSis();
                                Ac.Show();
                                Ac.NameUser.Content = user.Имя;
                                Ac.SurUser.Content = user.Фамилия;
                                Ac.RoleUser.Content = user.Отчетсво;
                                this.Close();
                                break;
                            default:
                                MessageBox.Show("Неверная роль пользователя.");
                                break;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Логин или пароль не верен");
                        cout--;
                        MessageBox.Show("Осталось попыток " + cout.ToString());

                        if (cout == 0)
                        {
                            cout = 3;
                            Captcha cap = new Captcha();
                            cap.Show();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к БД: " + ex.Message);
            }
        }

        private void TovariProsm_Click(object sender, RoutedEventArgs e)
        {
            Tovar t = new Tovar();
            t.Show();
        }
    }
}
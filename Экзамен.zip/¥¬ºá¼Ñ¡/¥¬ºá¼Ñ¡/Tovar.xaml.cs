﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Экзамен
{
    /// <summary>
    /// Логика взаимодействия для Tovar.xaml
    /// </summary>
    public partial class Tovar : Window
    {
        public Tovar()
        {
            InitializeComponent();

            // Загружаем данные товаров в DataGrid при загрузке окна
            LoadData();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Обработчик события SelectionChanged для DataGrid
            // (можно добавить логику, если нужно что-то делать при изменении выделения)
        }

        private void edit_Click(object sender, RoutedEventArgs e)
        {
            // Открываем окно редактирования товара
            EditTovar ET = new EditTovar();
            ET.Show();
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, выбран ли товар
            if (tovar_Table.SelectedItem != null)
            {
                // Подтверждаем удаление
                if (MessageBox.Show("Вы уверены, что хотите удалить эту запись?", "Удаление записи", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    // Получаем выбранный товар
                    if (tovar_Table.SelectedItem is Товар selectedTovar)
                    {
                        using (var context = new МEntities())
                        {
                            // Находим товар в базе данных по ID
                            var товарToDelete = context.Товар.FirstOrDefault(t => t.id_Товара == selectedTovar.id_Товара);

                            // Удаляем товар из базы данных
                            if (товарToDelete != null)
                            {
                                context.Товар.Remove(товарToDelete);
                                context.SaveChanges();

                                // Обновляем данные в DataGrid
                                LoadData();

                                MessageBox.Show("Запись успешно удалена.");
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void LoadData()
        {
            // Метод для загрузки данных товаров в DataGrid
            using (var context = new МEntities())
            {
                tovar_Table.ItemsSource = context.Товар.ToList();
            }
        }
    }
}
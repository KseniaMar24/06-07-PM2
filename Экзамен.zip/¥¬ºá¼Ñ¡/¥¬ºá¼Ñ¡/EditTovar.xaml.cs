﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Экзамен
{
    /// <summary>
    /// Логика взаимодействия для EditTovar.xaml
    /// </summary>
    public partial class EditTovar : Window
    {
        public EditTovar()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Получаем ID выбранного товара
            int товарID = GetSelectedTovarID();

            using (var context = new МEntities())
            {
                // Находим товар в базе данных по ID
                var тов = context.Товар.FirstOrDefault(t => t.id_Товара == товарID);

                if (тов != null)
                {
                    // Заполняем поля формы данными товара
                    name1.Text = тов.Категория;
                    opisanie.Text = тов.Описание;
                    proizv.Text = тов.Скидка;
                    kol.Text = тов.Количество.ToString();

                    // Обновляем источник данных для DataGrid
                    dataGridPatients.ItemsSource = context.Товар.ToList();
                }
                else
                {
                    MessageBox.Show("Товар не найден.");
                    this.Close();
                }
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получаем ID выбранного товара
                int товарID = GetSelectedTovarID();

                // Получаем данные из формы
                string Name = name1.Text;
                string Opisanie = opisanie.Text;
                string Proizv = proizv.Text;
                int kol;

                // Проверяем, что поле "Количество" является числом
                if (!int.TryParse(kol.Text, out kol))
                {
                    MessageBox.Show("Некорректное значение в поле 'Количество'. Введите число.");
                    return;
                }

                // Обновляем данные товара в базе данных
                using (var context = new МEntities())
                {
                    var existingТовар = context.Товар.Find(товарID);

                    if (existingТовар != null)
                    {
                        existingТовар.Категория = Name;
                        existingТовар.Описание = Opisanie;
                        existingТовар.Скидка = Proizv;
                        existingТовар.Количество = kol;

                        context.SaveChanges();
                        this.Close(); // Закрываем окно после успешного сохранения
                    }
                    else
                    {
                        MessageBox.Show("Товар не найден.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении данных: " + ex.Message);
            }
        }

        private int GetSelectedTovarID()
        {
            // Получаем выбранный товар из DataGrid
            Товар selectedТовар = dataGridPatients.SelectedItem as Товар;

            // Проверка, выбран ли товар
            if (selectedТовар == null)
            {
                MessageBox.Show("Выберите товар для редактирования.");
                return -1;
            }

            // Возвращаем ID выбранного товара
            return selectedТовар.id_Товара;
        }
    }
}